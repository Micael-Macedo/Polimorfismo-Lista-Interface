/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vendadispositivo;

/**
 *
 * @author Treinamento
 */
public class Celular extends Dispositivo implements PrescificaAcessorio{

    @Override
    public float adicionarCapa(String cor, String modelo, boolean temCapa) {
        if(temCapa){
            if (cor.equalsIgnoreCase("vermelha") || cor.equalsIgnoreCase("Azul") || cor.equalsIgnoreCase("Amarelo") && modelo.equalsIgnoreCase("CASE")){
                return 20f;
            }
            if (cor.equalsIgnoreCase("vermelha") || cor.equalsIgnoreCase("Azul") || cor.equalsIgnoreCase("Amarelo") && modelo.equalsIgnoreCase("SOFT")){
                return 20f;
            }
            else{
                return 15f;
            }
        }else{
            return 0f;
        }  
    }

    @Override
    public float adicionarCaneta(boolean temCaneta) {
        if (temCaneta) {
            return 20f;
        }else{
            return 0f;
        }
    }
    
}
