/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.vendadispositivo;

import java.util.ArrayList;

/**
 *
 * @author Treinamento
 */
public class VendaDispositivo {

    public static void main(String[] args) {
        Tablet tab1 = new Tablet();
        float valorCaneta = tab1.adicionarCaneta(true);
        System.out.println(valorCaneta);
        float valorCapa = tab1.adicionarCapa("vermelha", "soft", true);
        System.out.println(valorCapa);
        tab1.setValor(valorCapa + valorCaneta);
        
        ArrayList<Dispositivo> dispositivos = new ArrayList<>();
        dispositivos.add(tab1);
        
        System.out.println(dispositivos.get(0).getValor());
    }
}
